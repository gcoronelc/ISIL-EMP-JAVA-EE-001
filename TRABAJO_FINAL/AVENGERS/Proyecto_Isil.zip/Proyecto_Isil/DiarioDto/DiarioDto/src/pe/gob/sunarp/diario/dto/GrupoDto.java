package pe.gob.sunarp.diario.dto;

import java.util.Date;

public class GrupoDto {

    public String id_grpo;
    public String de_grpo;
    public String in_estd;
    public Date ts_usua_crea;
    public Date ts_usua_modi;
    public String id_usua_crea;
    public String id_usua_modi;
    public String co_area;
    public String in_tipo;
    public String in_prio;
    public String in_defe;

    public GrupoDto() {
    }

    public GrupoDto(String id_grpo, String de_grpo, String in_estd, Date ts_usua_crea, Date ts_usua_modi, String id_usua_crea, String id_usua_modi, String co_area, String in_tipo, String in_prio, String in_defe) {
        this.id_grpo = id_grpo;
        this.de_grpo = de_grpo;
        this.in_estd = in_estd;
        this.ts_usua_crea = ts_usua_crea;
        this.ts_usua_modi = ts_usua_modi;
        this.id_usua_crea = id_usua_crea;
        this.id_usua_modi = id_usua_modi;
        this.co_area = co_area;
        this.in_tipo = in_tipo;
        this.in_prio = in_prio;
        this.in_defe = in_defe;
    }

    public String getId_grpo() {
        return id_grpo;
    }

    public void setId_grpo(String id_grpo) {
        this.id_grpo = id_grpo;
    }

    public String getDe_grpo() {
        return de_grpo;
    }

    public void setDe_grpo(String de_grpo) {
        this.de_grpo = de_grpo;
    }

    public String getIn_estd() {
        return in_estd;
    }

    public void setIn_estd(String in_estd) {
        this.in_estd = in_estd;
    }

    public Date getTs_usua_crea() {
        return ts_usua_crea;
    }

    public void setTs_usua_crea(Date ts_usua_crea) {
        this.ts_usua_crea = ts_usua_crea;
    }

    public Date getTs_usua_modi() {
        return ts_usua_modi;
    }

    public void setTs_usua_modi(Date ts_usua_modi) {
        this.ts_usua_modi = ts_usua_modi;
    }

    public String getId_usua_crea() {
        return id_usua_crea;
    }

    public void setId_usua_crea(String id_usua_crea) {
        this.id_usua_crea = id_usua_crea;
    }

    public String getId_usua_modi() {
        return id_usua_modi;
    }

    public void setId_usua_modi(String id_usua_modi) {
        this.id_usua_modi = id_usua_modi;
    }

    public String getCo_area() {
        return co_area;
    }

    public void setCo_area(String co_area) {
        this.co_area = co_area;
    }

    public String getIn_tipo() {
        return in_tipo;
    }

    public void setIn_tipo(String in_tipo) {
        this.in_tipo = in_tipo;
    }

    public String getIn_prio() {
        return in_prio;
    }

    public void setIn_prio(String in_prio) {
        this.in_prio = in_prio;
    }

    public String getIn_defe() {
        return in_defe;
    }

    public void setIn_defe(String in_defe) {
        this.in_defe = in_defe;
    }
    
    
}
