
package pe.gob.sunarp.diario.dto;

import java.util.Date;


public class ActoDto {
    
  public String co_acto_rgst;
  public String de_acto_rgst;
  public String in_estd;
  public Date ts_usua_crea;
  public Date ts_usua_modi;
  public String id_usua_crea;
  public String id_usua_modi;

  public ActoDto() {
    }

    public ActoDto(String co_acto_rgst, String de_acto_rgst, String in_estd, Date ts_usua_crea, Date ts_usua_modi, String id_usua_crea, String id_usua_modi) {
        this.co_acto_rgst = co_acto_rgst;
        this.de_acto_rgst = de_acto_rgst;
        this.in_estd = in_estd;
        this.ts_usua_crea = ts_usua_crea;
        this.ts_usua_modi = ts_usua_modi;
        this.id_usua_crea = id_usua_crea;
        this.id_usua_modi = id_usua_modi;
    }

    public String getCo_acto_rgst() {
        return co_acto_rgst;
    }

    public void setCo_acto_rgst(String co_acto_rgst) {
        this.co_acto_rgst = co_acto_rgst;
    }

    public String getDe_acto_rgst() {
        return de_acto_rgst;
    }

    public void setDe_acto_rgst(String de_acto_rgst) {
        this.de_acto_rgst = de_acto_rgst;
    }

    public String getIn_estd() {
        return in_estd;
    }

    public void setIn_estd(String in_estd) {
        this.in_estd = in_estd;
    }

    public Date getTs_usua_crea() {
        return ts_usua_crea;
    }

    public void setTs_usua_crea(Date ts_usua_crea) {
        this.ts_usua_crea = ts_usua_crea;
    }

    public Date getTs_usua_modi() {
        return ts_usua_modi;
    }

    public void setTs_usua_modi(Date ts_usua_modi) {
        this.ts_usua_modi = ts_usua_modi;
    }

    public String getId_usua_crea() {
        return id_usua_crea;
    }

    public void setId_usua_crea(String id_usua_crea) {
        this.id_usua_crea = id_usua_crea;
    }

    public String getId_usua_modi() {
        return id_usua_modi;
    }

    public void setId_usua_modi(String id_usua_modi) {
        this.id_usua_modi = id_usua_modi;
    }
    
    
  
  
    
}
