
package pe.gob.sunarp.diario.dto;

import java.util.Date;

public class CriterioDto {
    
  public String id_criterio;
  public String de_criterio;
  public String in_estd;
  public Date ts_usua_crea;
  public Date ts_usua_modi;
  public String id_usua_crea;
  public String id_usua_modi;

    public CriterioDto() {
    }

    public CriterioDto(String id_criterio, String de_criterio, String in_estd, Date ts_usua_crea, String id_usua_crea, String id_usua_modi) {
        this.id_criterio = id_criterio;
        this.de_criterio = de_criterio;
        this.in_estd = in_estd;
        this.ts_usua_crea = ts_usua_crea;
        this.id_usua_crea = id_usua_crea;
        this.id_usua_modi = id_usua_modi;
    }

    public String getId_criterio() {
        return id_criterio;
    }

    public void setId_criterio(String id_criterio) {
        this.id_criterio = id_criterio;
    }

    public String getDe_criterio() {
        return de_criterio;
    }

    public void setDe_criterio(String de_criterio) {
        this.de_criterio = de_criterio;
    }

    public String getIn_estd() {
        return in_estd;
    }

    public void setIn_estd(String in_estd) {
        this.in_estd = in_estd;
    }

    public Date getTs_usua_crea() {
        return ts_usua_crea;
    }

    public void setTs_usua_crea(Date ts_usua_crea) {
        this.ts_usua_crea = ts_usua_crea;
    }

    public Date getTs_usua_modi() {
        return ts_usua_modi;
    }

    public void setTs_usua_modi(Date ts_usua_modi) {
        this.ts_usua_modi = ts_usua_modi;
    }

    public String getId_usua_crea() {
        return id_usua_crea;
    }

    public void setId_usua_crea(String id_usua_crea) {
        this.id_usua_crea = id_usua_crea;
    }

    public String getId_usua_modi() {
        return id_usua_modi;
    }

    public void setId_usua_modi(String id_usua_modi) {
        this.id_usua_modi = id_usua_modi;
    }
  
  
}
