package pe.egcc.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import pe.gob.sunarp.diario.dto.CriterioDto;
import pe.gob.sunarp.diario.service.CriterioService;

@WebServlet({ "/ConsultarCriterio"})
public class CriterioController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	protected void service(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		String path = request.getServletPath();
		switch (path) {
		case "/ConsultarCriterio":
			ConsultarCriterio(request, response);
			break;
	
		}

	}
	
	
	protected void ConsultarCriterio(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		// Datos
		String descripcion = request.getParameter("descripcion");
		// Proceso
		CriterioService criterioservice;
		criterioservice = new CriterioService();
		List<CriterioDto> lista = criterioservice.getCriterios(descripcion);
		// Crear cadena JSON
		Gson gson = new Gson();
		String cadenaJson = gson.toJson(lista);
		// Respuesta
		response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
	    response.getWriter().write(cadenaJson);
		response.getWriter().flush();
	}

}
