package pe.egcc.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import pe.gob.sunarp.diario.dto.ActoDto;
import pe.gob.sunarp.diario.service.ActoService;


@WebServlet({ "/ConsultarActo"})
public class ActoController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	
	protected void service(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		String path = request.getServletPath();
		switch (path) {
		case "/ConsultarActo":
			ConsultarActo(request, response);
			break;
	
		}

	}
	
	
	protected void ConsultarActo(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		// Datos
		String descripcion = request.getParameter("descripcion");
		// Proceso
		ActoService actoservice;
		actoservice = new ActoService();
		List<ActoDto> lista = actoservice.getActos(descripcion);
		// Crear cadena JSON
		Gson gson = new Gson();
		String cadenaJson = gson.toJson(lista);
		// Respuesta
		response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
	    response.getWriter().write(cadenaJson);
		response.getWriter().flush();
	}
}
