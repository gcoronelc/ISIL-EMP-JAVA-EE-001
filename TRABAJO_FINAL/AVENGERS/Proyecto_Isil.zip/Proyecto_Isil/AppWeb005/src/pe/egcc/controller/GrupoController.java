package pe.egcc.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import pe.gob.sunarp.diario.dto.GrupoDto;
import pe.gob.sunarp.diario.service.GrupoService;




@WebServlet({ "/ConsultarGruposxId","/ConsultarGruposxDescrip","/CrearGrupo",
	"/ActualizarGrupo","/AsignarSeccionAGrupo","/AsignarActoAGrupo","/AsignarCriterioAGrupo"})
public class GrupoController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		String path = request.getServletPath();
		switch (path) {
		case "/ConsultarGruposxId":
			consultarxId(request, response);
			break;
		case "/ConsultarGruposxDescrip":
			consultarxDescripcion(request, response);
			break;
		case "/CrearGrupo":
			CrearGrupo(request, response);
			break;
		case "/ActualizarGrupo":
			ActualizarGrupo(request, response);
			break;
		case "/AsignarSeccionAGrupo":
			AsignarSeccionAGrupo(request, response);
			break;	
		case "/AsignarActoAGrupo":
			AsignarActoAGrupo(request, response);
			break;
		case "/AsignarCriterioAGrupo":
			AsignarCriterioAGrupo(request, response);
			break;
		}
		
	}

	protected void consultarxId(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		// Datos
		String codigo = request.getParameter("codigo");
		String descripcion = "";
		// Proceso
		GrupoService gruposervice;
		gruposervice = new GrupoService();
		List<GrupoDto> lista = gruposervice.getGrupos(codigo, descripcion);
		// Crear cadena JSON
		Gson gson = new Gson();
		String cadenaJson = gson.toJson(lista);
		// Respuesta
		response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
	    response.getWriter().write(cadenaJson);
		response.getWriter().flush();
	}

	protected void consultarxDescripcion(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		// Datos
		String descripcion = request.getParameter("descripcion");
		String codigo = "";
		// Proceso
		GrupoService gruposervice;
		gruposervice = new GrupoService();
		List<GrupoDto> lista = gruposervice.getGrupos(codigo, descripcion);
		System.err.println("Grupos: " + lista.size());
		// Crear cadena JSON
		Gson gson = new Gson();
		String cadenaJson = gson.toJson(lista);
		// Respuesta
		response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
	    response.getWriter().write(cadenaJson);
		response.getWriter().flush();
	}
	
	protected void CrearGrupo(HttpServletRequest request, 
			HttpServletResponse response)throws ServletException, IOException{
		
		// Datos
        String descripcion = request.getParameter("descripcion");
        String estado = request.getParameter("estado");
        String registro = request.getParameter("registro");
        String prioridad = request.getParameter("prioridad");
        String tipo = request.getParameter("tipo");
    	// Proceso
		GrupoService gruposervice;
		gruposervice = new GrupoService();
		int aux = gruposervice.CrearGrupo(descripcion, estado, registro, prioridad, tipo);
		System.err.println("Grupos: " + aux);
		
		
		
	}
	
	protected void ActualizarGrupo(HttpServletRequest request, 
			HttpServletResponse response)throws ServletException, IOException{
		
		// Datos
		String codigo = request.getParameter("codigo");
        String descripcion = request.getParameter("descripcion");
        String estado = request.getParameter("estado");
        String registro = request.getParameter("registro");
        String prioridad = request.getParameter("prioridad");
        String tipo = request.getParameter("tipo");
    	// Proceso
		GrupoService gruposervice;
		gruposervice = new GrupoService();
		int aux = gruposervice.ActualizarGrupo(codigo, descripcion, estado, registro, prioridad, tipo);
		System.err.println("Grupos: " + aux);
		
		
		
	}
	
	protected void AsignarSeccionAGrupo(HttpServletRequest request, 
			HttpServletResponse response)throws ServletException, IOException{
		
		 // Datos
        String codsecc = request.getParameter("codsecc");
        String estado = request.getParameter("estado");
        String codgrup = request.getParameter("codgrup");
    	// Proceso
		GrupoService gruposervice;
		gruposervice = new GrupoService();
		int aux = gruposervice.AsignarSeccionAGrupo(codsecc,codgrup,estado);
		System.err.println("Grupos: " + aux);
		
		
		
	}
	
	protected void AsignarActoAGrupo(HttpServletRequest request, 
			HttpServletResponse response)throws ServletException, IOException{
		
		// Datos
        String codacto = request.getParameter("codacto");
        String estado = request.getParameter("estado");
        String codgrup = request.getParameter("codgrup");
    	// Proceso
		GrupoService gruposervice;
		gruposervice = new GrupoService();
		int aux = gruposervice.AsignarActoAGrupo(codacto, codgrup, estado);
		System.err.println("Grupos: " + aux);
		
		
		
	}
	
	protected void AsignarCriterioAGrupo(HttpServletRequest request, 
			HttpServletResponse response)throws ServletException, IOException{
		
		// Datos
        String codcriter = request.getParameter("codcriter");
        String estado = request.getParameter("estado");
        String codgrup = request.getParameter("codgrup");
    	// Proceso
		GrupoService gruposervice;
		gruposervice = new GrupoService();
		int aux = gruposervice.AsignarCriterioAGrupo(codcriter, codgrup, estado);
		System.err.println("Grupos: " + aux);
		
		
		
	}
}
