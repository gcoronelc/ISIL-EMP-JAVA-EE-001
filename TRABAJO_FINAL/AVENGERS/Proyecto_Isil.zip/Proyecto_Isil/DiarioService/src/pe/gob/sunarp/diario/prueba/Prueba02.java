
package pe.gob.sunarp.diario.prueba;

import pe.gob.sunarp.diario.service.GrupoService;


public class Prueba02 {

   
    public static void main(String[] args) {
                
        // Datos
        String codigo="G0002";
        String descripcion = "COMPRA VENTA SIMPLE";
        String estado = "A";
        String registro = "2100";
        String prioridad="1";
        String tipo="N";
    
        // Proceso
        GrupoService grupoService = new GrupoService();
        int aux = grupoService.ActualizarGrupo(codigo, descripcion, estado, registro, prioridad, tipo);
    
        // Reporte
        if( grupoService.getCode() == 1){

            System.out.println(grupoService.getMensaje());

        } else {
            System.err.println(grupoService.getMensaje());
        }
    }
    
}
