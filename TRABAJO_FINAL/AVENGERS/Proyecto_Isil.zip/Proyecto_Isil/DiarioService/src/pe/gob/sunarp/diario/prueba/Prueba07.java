
package pe.gob.sunarp.diario.prueba;

import java.util.List;
import pe.gob.sunarp.diario.dto.ActoDto;
import pe.gob.sunarp.diario.service.ActoService;


public class Prueba07 {

   
    public static void main(String[] args) {
         // Datos
        String descripcion="EMBARGO";

        // Proceso
        ActoService actoService = new ActoService();
        List<ActoDto> lista = actoService.getActos(descripcion);

        // Reporte
        if (actoService.getCode() == 1) {

            for (ActoDto dto : lista) {
                System.out.println(dto.getCo_acto_rgst() + " - " + dto.getDe_acto_rgst() + " - " + dto.getIn_estd());
            }

        } else {
            System.err.println(actoService.getMensaje());
        }
    }
    
}
