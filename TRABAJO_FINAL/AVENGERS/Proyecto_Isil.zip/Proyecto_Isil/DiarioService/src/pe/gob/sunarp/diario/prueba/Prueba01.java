
package pe.gob.sunarp.diario.prueba;

import pe.gob.sunarp.diario.dto.GrupoDto;
import pe.gob.sunarp.diario.service.GrupoService;


public class Prueba01 {


    public static void main(String[] args) {
        
        // Datos
        String descripcion = "HIPOTECA";
        String estado = "A";
        String registro = "2100";
        String prioridad="1";
        String tipo="N";
    
        // Proceso
        GrupoService grupoService = new GrupoService();
        int aux = grupoService.CrearGrupo(descripcion, estado, registro, prioridad, tipo);
    
        // Reporte
        if( grupoService.getCode() == 1){

            System.out.println(grupoService.getMensaje());

        } else {
            System.err.println(grupoService.getMensaje());
        }
    
  }
        
    }
    

