
package pe.gob.sunarp.diario.prueba;

import pe.gob.sunarp.diario.service.GrupoService;


public class Prueba05 {

  
    public static void main(String[] args) {
        
         // Datos
        String codacto = "00001";
        String estado = "A";
        String codgrup = "G0001";
   
    
        // Proceso
        GrupoService grupoService = new GrupoService();
        int aux = grupoService.AsignarActoAGrupo(codacto, codgrup, estado);
    
        // Reporte
        if( grupoService.getCode() == 1){

            System.out.println(grupoService.getMensaje());

        } else {
            System.err.println(grupoService.getMensaje());
        }
    }
    
}
