/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.sunarp.diario.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.gob.sunarp.diario.database.AccesoDB;
import pe.gob.sunarp.diario.dto.CriterioDto;

/**
 *
 * @author SEGUNDO
 */
public class CriterioService extends AbstractService {

    //servicio 8: obtener un listado de criterios segun la descripcion ingresada INPUT: descripcion; OUTPUT: Lista de CriterioDto
    public List<CriterioDto> getCriterios(String descripcion) {

        //Datos
        Connection cn = null;
        PreparedStatement pstm = null;
        this.setCode(1);
        List<CriterioDto> lista = new ArrayList<>();

        //proceso
        try {
            cn = AccesoDB.getConnection();
            String sql = "select * from TA_CRITERIO WHERE DE_CRITERIO LIKE ? ";
            pstm = cn.prepareCall(sql);
            pstm.setString(1,"%"+ descripcion + "%");
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                CriterioDto dto = mapRow(rs);
                lista.add(dto);
            }
            rs.close();
            pstm.close();
        } catch (Exception e) {
            this.setCode(-1);
            this.setMensaje(e.getMessage());
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }

        return lista;
    }

    private CriterioDto mapRow(ResultSet rs) throws SQLException {

        //Datos        
        CriterioDto dto = new CriterioDto();

        dto.setId_criterio(rs.getString("ID_CRITERIO"));
        dto.setDe_criterio(rs.getString("DE_CRITERIO"));
//        dto.setId_usua_crea(rs.getString("ID_USUA_CREA"));
//        dto.setId_usua_modi(rs.getString("ID_USUA_MODI"));
        dto.setIn_estd(rs.getString("IN_ESTD"));
//        dto.setTs_usua_crea(rs.getDate("TS_USUA_CREA"));
//        dto.setTs_usua_modi(rs.getDate("TS_USUA_MODI"));

        return dto;

    }
}
