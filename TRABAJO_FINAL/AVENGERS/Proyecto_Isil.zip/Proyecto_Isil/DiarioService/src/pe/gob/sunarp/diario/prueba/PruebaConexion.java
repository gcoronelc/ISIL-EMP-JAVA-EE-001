package pe.gob.sunarp.diario.prueba;

import java.sql.Connection;
import pe.gob.sunarp.diario.database.AccesoDB;

public class PruebaConexion {

    public static void main(String[] args) {
        try {
            Connection cn = AccesoDB.getConnection();
            System.out.println("Ok");
            cn.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
