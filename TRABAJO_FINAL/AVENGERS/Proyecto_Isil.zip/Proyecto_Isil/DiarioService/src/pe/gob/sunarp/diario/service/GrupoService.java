
package pe.gob.sunarp.diario.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.gob.sunarp.diario.database.AccesoDB;
import pe.gob.sunarp.diario.dto.GrupoDto;


public class GrupoService  extends AbstractService{
        //servicios:
    //servicio 1: Crear Grupo INPUTS: descripción, estado, Registro, Prioridad ; OUTPUT: ok= 1 Error = -1
    public int CrearGrupo(String descripcion, String estado, String registro, String prioridad, String tipo) {

        //Datos
        String secuencia;
        Connection cn = null;
        PreparedStatement pstm = null;
        this.setCode(1);
        //Proceso
        //tarea 1: obtenerid
        secuencia = ObtenerIdGrupo(cn, pstm);
        //tarea 2: crear grupo
        try {
            cn = AccesoDB.getConnection();
            String sql = "insert "
                    + "into ta_grupo(ID_GRPO,DE_GRPO,IN_ESTD,"
                    + "TS_USUA_CREA,TS_USUA_MODI,ID_USUA_CREA,"
                    + "ID_USUA_MODI,CO_AREA,IN_TIPO,IN_PRIO,IN_DEFE)"
                    + " values(?,?,?,SYSDATE,NULL,'99999',NULL,?,?,?,?)";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, secuencia);
            pstm.setString(2, descripcion);
            pstm.setString(3, estado);
            pstm.setString(4, registro);
            pstm.setString(5, tipo);
            pstm.setString(6, prioridad);
            pstm.setString(7, prioridad);
            pstm.executeUpdate();
            pstm.close();

            cn.commit();
            this.setCode(1);
            this.setMensaje("Se creo correctamente el grupo de distribución.");
        } catch (Exception e) {
            try {
                cn.rollback();
            } catch (Exception e1) {
            }
            this.setCode(-1);
            this.setMensaje(e.getMessage());
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }
        return this.getCode();
    }

    //servicio 2: Actualizar Grupo INPUTS: codigo,descripción, estado, Registro, Prioridad ; OUTPUT: ok= 1 Error = -1 Ningun registro actualizado = 0
    public int ActualizarGrupo(String codigo, String descripcion, String estado, String registro, String prioridad, String tipo) {

        //Datos
        Connection cn = null;
        PreparedStatement pstm = null;
        this.setCode(1);

        //Proceso
        //tarea 1: Actualizar grupo
        try {
            cn = AccesoDB.getConnection();
            String sql = " update ta_grupo \n"
                    + " set DE_GRPO = ?,\n"
                    + " IN_ESTD = ?,\n"
                    + " TS_USUA_MODI = SYSDATE,\n"
                    + " ID_USUA_MODI = '99999',\n"
                    + " CO_AREA = ?,\n"
                    + " IN_TIPO = ?,\n"
                    + " IN_PRIO = ?,\n"
                    + " IN_DEFE = ?\n"
                    + " where ID_GRPO = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, descripcion);
            pstm.setString(2, estado);
            pstm.setString(3, registro);
            pstm.setString(4, tipo);
            pstm.setString(5, prioridad);
            pstm.setString(6, prioridad);
            pstm.setString(7, codigo);
            pstm.executeUpdate();
            pstm.close();

            cn.commit();
            this.setCode(1);
            this.setMensaje("Se actualizó correctamente a " + descripcion);
        } catch (Exception e) {
            try {
                cn.rollback();
            } catch (Exception e1) {
            }
            this.setCode(-1);
            this.setMensaje(e.getMessage());
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }
        return this.getCode();
    }

    //servicio 3: Obtener un listado de grupos segun el criterios de busqueda realizado INPUT:codigo,descripcion  ; OUTPUT Lista de GrupoDto
    public List<GrupoDto> getGrupos(String codigo,String descripcion) {
        //Datos
        Connection cn = null;
        PreparedStatement pstm = null;
        this.setCode(1);
        List<GrupoDto> lista = new ArrayList<>();
        int tipobusqueda= 1;
        //Proceso 
       if (codigo.length()==0 || codigo.equals(" ")) {

            tipobusqueda = 2;
        }

        switch (tipobusqueda) {

            case 1:
                lista = getGruposxCodigo(codigo, cn, pstm);
                break;
            case 2:
                lista = getGruposxDescripcion(descripcion, cn, pstm);
                break;
        }

        return lista;

    }
    
    //servicio 4: Asignar sección a grupo INPUT: codigo seccion, codigo grupo,estado; OUTPUT : ok= 1 Error = -1 Ningun registro actualizado = 0 
    public int AsignarSeccionAGrupo(String codsecc,String codgrup,String estado){
    
        //Datos
        Connection cn = null;
        PreparedStatement pstm = null;
        this.setCode(1);
        //Proceso
        //tarea 1: asignar sección a grupo
        try {
            cn = AccesoDB.getConnection();
            String sql = "insert into TA_GRPO_SECC(id_grpo,co_secc,fe_crea,fe_modi,in_estd) "
                    + "values(?,?,SYSDATE,NULL,?)";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, codgrup);
            pstm.setString(2, codsecc);
            pstm.setString(3, estado);
            pstm.executeUpdate();
            pstm.close();

            cn.commit();
            this.setCode(1);
            this.setMensaje("Sección asignada correctamente al grupo." + codgrup);
        } catch (Exception e) {
            try {
                cn.rollback();
            } catch (Exception e1) {
            }
            this.setCode(-1);
            this.setMensaje(e.getMessage());
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }
        return this.getCode();
    }
    
    //servicio 5: Asignar acto a grupo INPUT: codigo acto, codigo grupo,estado; OUTPUT : ok= 1 Error = -1 Ningun registro actualizado = 0 
    public int AsignarActoAGrupo(String codacto,String codgrup,String estado){
    
        //Datos
        Connection cn = null;
        PreparedStatement pstm = null;
        this.setCode(1);
        //Proceso
        //tarea 1: asignar sección a grupo
        try {
            cn = AccesoDB.getConnection();
            String sql = "insert into TA_ACTO_GRPO(co_acto_rgst,id_grpo,in_estd,"
                        + "ts_usua_crea,ts_usua_modi,id_usua_modi,id_usua_crea) "
                        + "values(?,?,?,SYSDATE,NULL,NULL,'99999')";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, codacto);
            pstm.setString(2, codgrup);
            pstm.setString(3, estado);
            pstm.executeUpdate();
            pstm.close();

            cn.commit();
            this.setCode(1);
            this.setMensaje("Acto asignado correctamente al grupo." + codgrup);
        } catch (Exception e) {
            try {
                cn.rollback();
            } catch (Exception e1) {
            }
            this.setCode(-1);
            this.setMensaje(e.getMessage());
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }
        return this.getCode();
    }
    
    //servicio 6: Asignar acto a grupo INPUT: codigo criterio, codigo grupo,estado; OUTPUT : ok= 1 Error = -1 Ningun registro actualizado = 0 
    public int AsignarCriterioAGrupo(String codcriter,String codgrup,String estado){
    
        //Datos
        Connection cn = null;
        PreparedStatement pstm = null;
        this.setCode(1);
        //Proceso
        //tarea 1: asignar sección a grupo
        try {
            cn = AccesoDB.getConnection();
            String sql = "insert into ta_crite_grpo(id_criterio,id_grpo,in_estd,"
                       + "ts_usua_crea,ts_usua_modi,id_usua_modi,id_usua_crea) values(?,?,?,SYSDATE,NULL,NULL,'99999')";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, codcriter);
            pstm.setString(2, codgrup);
            pstm.setString(3, estado);
            pstm.executeUpdate();
            pstm.close();

            cn.commit();
            this.setCode(1);
            this.setMensaje("Criterio asignado correctamente al grupo." + codgrup);
        } catch (Exception e) {
            try {
                cn.rollback();
            } catch (Exception e1) {
            }
            this.setCode(-1);
            this.setMensaje(e.getMessage());
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }
        return this.getCode();
    }
      
    
    private String ObtenerIdGrupo(Connection cn, PreparedStatement pstm) {
        //Datos
        String cont = null;
        this.setCode(1);
        //Proceso
        try {
            cn = AccesoDB.getConnection();
            String sql = "select secu from (select 'G'||nvl(lpad((max(substr(id_grpo,2,4))+1),4,0),'0001') secu from ta_grupo)";
            pstm = cn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            rs.next();
            cont = rs.getString("secu");
            rs.close();
            pstm.close();

        } catch (Exception e) {
            this.setCode(-1);
            this.setMensaje(e.getMessage());
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }

        return cont;

    }

    private List<GrupoDto> getGruposxCodigo(String codigo, Connection cn, PreparedStatement pstm) {
        //Datos
        List<GrupoDto> lista2 = new ArrayList<>();
        this.setCode(1);
        //Proceso
        try {
            cn = AccesoDB.getConnection();
            String sql = "select * from ta_grupo where ID_GRPO = ? ";
            pstm = cn.prepareCall(sql);
            pstm.setString(1,codigo);
            ResultSet rs  = pstm.executeQuery();
            while(rs.next()){
                GrupoDto dto = mapRow(rs);
                lista2.add(dto);
            }
            rs.close();
            pstm.close();
        } catch (Exception e) {
            this.setCode(-1);
            this.setMensaje(e.getMessage());
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }

        return lista2;
    }
   
    private List<GrupoDto> getGruposxDescripcion(String descripcion, Connection cn, PreparedStatement pstm) {
              //Datos
        List<GrupoDto> lista2 = new ArrayList<>();
        this.setCode(1);
        //Proceso
        try {
            cn = AccesoDB.getConnection();
            String sql = "select * from ta_grupo "
                       + " where DE_GRPO LIKE ? ";
            pstm = cn.prepareCall(sql);
            pstm.setString(1,descripcion + "%");
            ResultSet rs  = pstm.executeQuery();
            while(rs.next()){
                GrupoDto dto = mapRow(rs);
                lista2.add(dto);
            }
            rs.close();
            pstm.close();
        } catch (Exception e) {
            this.setCode(-1);
            this.setMensaje(e.getMessage());
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }

        return lista2;
    }

    private GrupoDto mapRow(ResultSet rs) throws SQLException{
        
        //Datos        
        GrupoDto dto = new GrupoDto();
                  
                  dto.setId_grpo(rs.getString("ID_GRPO"));
                  dto.setDe_grpo(rs.getString("DE_GRPO"));
                  dto.setIn_estd(rs.getString("IN_ESTD"));
                  dto.setCo_area(rs.getString("CO_AREA"));
                  dto.setId_usua_crea(rs.getString("ID_USUA_CREA"));
                  dto.setId_usua_modi(rs.getString("ID_USUA_MODI"));
                  dto.setIn_defe(rs.getString("IN_DEFE"));
                  dto.setIn_prio(rs.getString("IN_PRIO"));
                  dto.setIn_tipo(rs.getString("IN_TIPO"));
                  dto.setTs_usua_crea(rs.getDate("TS_USUA_CREA"));
                  dto.setTs_usua_modi(rs.getDate("TS_USUA_MODI"));
                  
                  return dto;
             
    }
    

    

}
