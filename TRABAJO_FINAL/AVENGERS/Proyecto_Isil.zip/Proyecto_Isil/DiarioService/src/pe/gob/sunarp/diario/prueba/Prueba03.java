package pe.gob.sunarp.diario.prueba;

import java.util.List;
import pe.gob.sunarp.diario.dto.GrupoDto;
import pe.gob.sunarp.diario.service.GrupoService;

public class Prueba03 {

    public static void main(String[] args) {

        // Datos
        String codigo= "";
        String descripcion="ANOTACION";

        // Proceso
        GrupoService grupoService = new GrupoService();
        List<GrupoDto> lista = grupoService.getGrupos(codigo,descripcion);

        // Reporte
        if (grupoService.getCode() == 1) {

            for (GrupoDto dto : lista) {
                System.out.println(dto.getId_grpo() + " - " + dto.getDe_grpo() + " - " + dto.getCo_area());
            }

        } else {
            System.err.println(grupoService.getMensaje());
        }

    }

}
