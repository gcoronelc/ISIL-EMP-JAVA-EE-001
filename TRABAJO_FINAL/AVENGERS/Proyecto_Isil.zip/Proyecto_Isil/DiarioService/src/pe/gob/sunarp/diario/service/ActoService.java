/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.gob.sunarp.diario.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.gob.sunarp.diario.database.AccesoDB;
import pe.gob.sunarp.diario.dto.ActoDto;

/**
 *
 * @author SEGUNDO
 */
public class ActoService extends AbstractService {

    //servicio 7: obtener un listado de actos segun la descripcion ingresada INPUT: descripcion; OUTPUT: Lista de ActoDto
    public List<ActoDto> getActos(String descripcion) {
        //Datos
        Connection cn = null;
        PreparedStatement pstm = null;
        this.setCode(1);
        List<ActoDto> lista = new ArrayList<>();
        //Proceso
        try {
            cn = AccesoDB.getConnection();
            String sql = "SELECT *  FROM TP_ACTO_RGST where de_acto_rgst like ? ";

            pstm = cn.prepareCall(sql);
            pstm.setString(1,"%"+ descripcion + "%");
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                ActoDto dto = mapRow(rs);
                lista.add(dto);
            }
            rs.close();
            pstm.close();
        } catch (Exception e) {
            this.setCode(-1);
            this.setMensaje(e.getMessage());
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }

        return lista;
    }

    private ActoDto mapRow(ResultSet rs) throws SQLException {

        //Datos        
        ActoDto dto = new ActoDto();

        dto.setCo_acto_rgst(rs.getString("CO_ACTO_RGST"));
        dto.setDe_acto_rgst(rs.getString("DE_ACTO_RGST"));
//        dto.setId_usua_crea(rs.getString("ID_USUA_CREA"));
//        dto.setId_usua_modi(rs.getString("ID_USUA_MODI"));
        dto.setIn_estd(rs.getString("IN_ESTD"));
//        dto.setTs_usua_crea(rs.getDate("TS_USUA_CREA"));
//        dto.setTs_usua_modi(rs.getDate("TS_USUA_MODI"));

        return dto;

    }

}
