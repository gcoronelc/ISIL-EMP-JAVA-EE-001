
package pe.gob.sunarp.diario.prueba;

import java.util.List;
import pe.gob.sunarp.diario.dto.CriterioDto;
import pe.gob.sunarp.diario.service.CriterioService;


public class Prueba08 {

   
    public static void main(String[] args) {
        
        // Datos
        String descripcion=" ";

        // Proceso
        CriterioService criterioService = new CriterioService();
        List<CriterioDto> lista = criterioService.getCriterios(descripcion);

        // Reporte
        if (criterioService.getCode() == 1) {

            for (CriterioDto dto : lista) {
                System.out.println(dto.getId_criterio() + " - " + dto.getDe_criterio() + " - " + dto.getIn_estd());
            }

        } else {
            System.err.println(criterioService.getMensaje());
        }
    }
    
}
